<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="creatures" tilewidth="16" tileheight="16" spacing="1" tilecount="180" columns="10">
 <image source="../Tilemap/tilemap.png" width="170" height="306"/>
</tileset>
