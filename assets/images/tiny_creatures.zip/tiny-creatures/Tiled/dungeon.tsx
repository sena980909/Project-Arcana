<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="dungeon" tilewidth="16" tileheight="16" spacing="1" tilecount="132" columns="12">
 <image source="../Tilemap/Kenney_tiny_dungeon.png" width="203" height="186"/>
</tileset>
